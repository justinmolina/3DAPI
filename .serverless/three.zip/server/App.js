import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       <img src="https://images.unsplash.com/photo-1575493035843-9560639476d6?ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8bWVycnklMjBjaHJpc3RtYXN8ZW58MHx8MHx8&ixlib=rb-1.2.1&w=1000&q=80"></img>
          Hello from React!!
      </header>
    </div>
  );
}

export default App;
